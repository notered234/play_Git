//
//  ViewController.h
//  haha
//
//  Created by notered234 on 2015/4/27.
//  Copyright (c) 2015年 notered234. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *myDisplay;
- (IBAction)digitBtn:(UIButton *)sender;
- (IBAction)optBtn:(UIButton *)sender;
- (IBAction)equBtn:(UIButton *)sender;


@end

