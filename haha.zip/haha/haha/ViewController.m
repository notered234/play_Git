//
//  ViewController.m
//  haha
//
//  Created by notered234 on 2015/4/27.
//  Copyright (c) 2015年 notered234. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
{
    BOOL firstClick;
    NSString *opt;
    NSString *opt1;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    firstClick = YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)digitBtn:(UIButton *)sender {
    NSString *digit = [sender currentTitle];
    
    if (firstClick == YES) {
        self.myDisplay.text = digit;
        if(![digit isEqualToString:@"0"]){
            firstClick = NO;
        }
    }else{
        self.myDisplay.text = [self.myDisplay.text stringByAppendingString:digit];
    }
    
    
}

- (IBAction)optBtn:(UIButton *)sender {
    
    opt = [sender currentTitle];
    opt1 = self.myDisplay.text;
    self.myDisplay.text = @"";
    firstClick = YES;
}

- (IBAction)equBtn:(UIButton *)sender {
    int o1, o2, result;
    o1 = [opt1 intValue];
    o2 = [self.myDisplay.text intValue];
    if ([opt isEqualToString:@"+"]) {
        result = o1 + o2;
    }else if ([opt isEqualToString:@"-"]) {
        result = o1 - o2;
    }else if ([opt isEqualToString:@"*"]) {
        result = o1 * o2;
    }else if ([opt isEqualToString:@"/"]) {
        result = o1 / o2;
    }
    
    self.myDisplay.text = [NSString stringWithFormat:@"%d",result];
    
}







@end
